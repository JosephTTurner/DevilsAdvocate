
			elements = document.getElementsByTagName('p');
			otherElements = document.getElementsByTagName('span');
			for(x = 0; x < elements.length; x++){
				elements[x].style.setProperty('color', 'red', 'important');
			}
